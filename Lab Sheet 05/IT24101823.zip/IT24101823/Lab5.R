setwd("C:\\Users\\it24101843\\Desktop\\IT24101843\\Lab 5")
getwd()

data <- read.table("Data.txt", header =TRUE ,sep=",")
fix(data)
attach(data)
names(data)<-c("X1", "X2")
attach(data)

hist(X2,main= "Histogram for number of Shareholders")
hist(X2,main= "Histogram for number of Shareholders",breaks = seq(130,270,length = 8),right = FALSE)

histogram<-hist(X2,main="Histogram for number of shareholders",breaks = seq(130,270,length = 8),right = FALSE)

breaks <- round(histogram$breaks)
freq<- histogram$counts
mids<-histogram$mids

classes <- c()

for(i in 1 : length(breaks)-1){
  classes[i] <- paste0("[",breaks[i],",",breaks[i+1],")")
}


cbind(classes = classes, frequency = freq)

# Part 4: Frequency Polygon

# Draw frequency polygon on the same plot (assuming a histogram was plotted before)
lines(mids, freq)

# Draw frequency polygon in a new plot
plot(
  mids, freq,
  type = "l",
  main = "Frequency Polygon for Shareholders",
  xlab = "Shareholders",
  ylab = "Frequency",
  ylim = c(0, max(freq))
)

# Part 5: Cumulative Frequency Polygon (Ogive)

# Calculate cumulative frequencies
cum.freq <- cumsum(freq)

# Initialize a vector to store cumulative frequencies for plotting
new <- c()

# Populate 'new' with cumulative frequencies, aligning with class breaks
for(i in 1:length(breaks)) {
  if(i == 1) {
    new[i] <- 0
  } else {
    new[i] <- cum.freq[i - 1]
  }
}

# Plot the cumulative frequency polygon
plot(
  breaks, new,
  type = "l",
  main = "Cumulative Frequency Polygon for Shareholders",
  xlab = "Shareholders",
  ylab = "Cumulative Frequency",
  ylim = c(0, max(cum.freq))
)

# Display a table of upper class limits and cumulative frequencies
cbind(Upper = breaks, CumFreq = new)

#excersice
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = ",")

hist(
  Delivery_Times$X2,
  main = "Histogram of Delivery Times",
  breaks = seq(20, 70, length.out = 10),
  right = FALSE,
  xlab = "Delivery Time",
  ylab = "Frequency"
)
